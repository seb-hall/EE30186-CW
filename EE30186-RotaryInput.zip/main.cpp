//  main.cpp
//  EE30186 CW
//
//  This file is the program entry point and controls the overall
//  program control flow

#include "mbed.h"
#include "RotaryInput.h"

int main() {

    //  initialize modules
    RotaryInput_Init();

    while (true) {
        //  get updates
        int encoderPosition = RotaryInput_GetPosition();

        // print updates
        printf("POSITION: %d\n", encoderPosition);
    }
}
